/**
 * WordPress dependencies
 */
import { createRegistry } from '@wordpress/data';

const DataStoreRegistry = createRegistry();

export default DataStoreRegistry;
